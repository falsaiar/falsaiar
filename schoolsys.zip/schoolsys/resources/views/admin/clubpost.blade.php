
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>School</title>
      <link rel="stylesheet" href="../../bootstrap.css" media="screen">
    <link rel="stylesheet" href="../../custom.min.css">
    <link rel="stylesheet" href="../../comment.css">
    

  </head>

<body style="margin-top: -50px;">
	<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">School</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="{{ route('adminmembers') }}">Home <span class="sr-only">(current)</span></a></li>

      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="{{ route('logout') }}">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

    <div class="container" >
    <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-4">
            <div class="list-group table-of-contents">
              <a class="list-group-item" href="{{ route('adminmembers') }}">Members</a>
              <a class="list-group-item" href="{{ route('adminclubs') }}">Clubs</a>
            </div>
          </div>
          <div class="col-lg-9 col-md-9 col-sm-8">
          @include('includes.error')
      @include('includes.warning')
      @include('includes.success')
          		<div class="row">
          		<h2>{{ $clubs->title }}</h2>
          			<form method="post" action="{{ route('adminsaveclubpost',$clubs->id) }}" id="Status">
                <div class="form-group with-icon label-floating is-empty">
                  <label class="control-label">Share Post to all Members in the Club..</label>
                  <textarea class="form-control" placeholder="{{ Auth::user()->profile->first()->lname }} {{ Auth::user()->profile->first()->fname }} Send a Post to Members of {{ $clubs->title }}" name="post"></textarea>
                </div>
                <button class="btn btn-primary btn-md-2" type="submit">Share</button>
                <input type="hidden" name="_token" value="{{ Session::token() }}">
        </form>
				</div>
				<hr>
        @foreach($clubpost as $post)
        <div class="detailBox">
            <div class="titleBox">
              <label>
              <div class="commenterImage">
                          <img src="{{ URL::to('avatar') }}/{{ $post->user->profile->first()->avatar }}" />
                        </div>
                        Post By {{ $post->user->profile->first()->lname }} {{ $post->user->profile->first()->fname }}  ( <small>{{ $post->created_at->diffForHumans() }}</small> )</label>            </div>
            <div class="commentBox">
                <p class="taskDescription">{{ $post->post }}</p>
                    <ul class="commentList">
                    @foreach ($post->comment  as $comment)
                        <li>
                            <div class="commenterImage">
                              <img src="{{ URL::to('avatar') }}/{{ $comment->user->profile->first()->avatar }}" />
                            </div>
                            <div class="commentText">
                                <p class="">{{ $comment->comment }}</p> <span class="date sub-text">Comment By {{ $comment->user->profile->first()->lname }} {{ $comment->user->profile->first()->fname }}  {{ $comment->created_at->diffForHumans() }}</span>
                            </div>
                        </li>
                    @endforeach
                    </ul>
            </div>
        </div>
        @endforeach
				
          
    </div>

    </div>
       <!-- Bootstrap core JavaScript
    ================================================== -->
        <script src="../../bootstrap.min.js"></script>
    <script src="../../custom.js"></script


<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>

<!-- Laravel Javascript Validation -->
<script type="text/javascript" src="{{ asset('vendor/jsvalidation/js/jsvalidation.js')}}"></script>
{!! JsValidator::formRequest('App\Http\Requests\PostRequest', '#SignIn') !!}
  </body>
</html>
