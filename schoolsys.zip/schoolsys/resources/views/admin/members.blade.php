
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>School</title>
      <link rel="stylesheet" href="../../bootstrap.css" media="screen">
    <link rel="stylesheet" href="../../custom.min.css">
    <link rel="stylesheet" href="../../comment.css">
    

  </head>

<body style="margin-top: -50px;">
	<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">School</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="{{ route('adminmembers') }}">Home <span class="sr-only">(current)</span></a></li>

      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="{{ route('logout') }}">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

    <div class="container" >
    <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-4">
            <div class="list-group table-of-contents">
              <a class="list-group-item" href="{{ route('adminmembers') }}">Members</a>
              <a class="list-group-item" href="{{ route('adminclubs') }}">Clubs</a>
            </div>
          </div>
          <div class="col-lg-9 col-md-9 col-sm-8">
          		<div class="row">
          		<h2>Members</h2>
          			<table class="table table-striped">
          				<thead>
          					<tr>
          						<th>Last Name</th>
                      <th>First Name</th>
                      <th>Email</th>
          						<th>Action</th>
          					</tr>
          				</thead>
          				<tbody>
          				@foreach($members as $member)
          					<tr>
          						<td>{{ $member->profile->first()->lname }}</td>
          						<td>{{ $member->profile->first()->fname }}</td>
                      <td>{{ $member->email }}</td>
                      <td><a href="{{ route('profile',$member->id) }}">Profile</a></td>
          					</tr>
          				@endforeach
          				</tbody>
          			</table>
				</div>
				<hr>
				
          
    </div>

    </div>
       <!-- Bootstrap core JavaScript
    ================================================== -->
        <script src="../../bootstrap.min.js"></script>
    <script src="../../custom.js"></script


<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>

<!-- Laravel Javascript Validation -->
<script type="text/javascript" src="{{ asset('vendor/jsvalidation/js/jsvalidation.js')}}"></script>
{!! JsValidator::formRequest('App\Http\Requests\PostRequest', '#SignIn') !!}
  </body>
</html>
