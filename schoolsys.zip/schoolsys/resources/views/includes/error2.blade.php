@if($errors->any())
					<div id="card-alert" class="card red">
                      <div class="card-content white-text">
                        @foreach ($errors->all() as $error)
					    <p><i class="mdi-alert-error"></i>{{ $error }}</p>
					    @endforeach
                      </div>
                      <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    @endif