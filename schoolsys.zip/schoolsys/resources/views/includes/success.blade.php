@if(Session::has('flash_messagex'))
<div class="alert alert-success alert-dismissible fade in">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
  {{ Session::get('flash_messagex') }}
</div>
@endif