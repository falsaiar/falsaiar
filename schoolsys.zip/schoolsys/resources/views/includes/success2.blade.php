@if(Session::has('flash_messagex'))
					<div id="card-alert" class="card green">
                      <div class="card-content white-text">
                        <p><i class="mdi-navigation-check"></i> {{ Session::get('flash_messagex') }}</p>
                      </div>
                      <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    @endif