<!DOCTYPE html>
<html lang="en">
<head>

	<title>@yield('title')</title>

	<!-- Required meta tags always come first -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="x-ua-compatible" content="ie=edge">

	<!-- Main Font -->
	<script src="{{ URL::to('assets/js/webfontloader.min.js') }}"></script>
	<script>
		WebFont.load({
			google: {
				families: ['Roboto:300,400,500,700:latin']
			}
		});
	</script>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" type="text/css" href="{{ URL::to('assets/Bootstrap/dist/css/bootstrap-reboot.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ URL::to('assets/Bootstrap/dist/css/bootstrap.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ URL::to('assets/Bootstrap/dist/css/bootstrap-grid.css') }}">

	<!-- Theme Styles CSS -->
	<link rel="stylesheet" type="text/css" href="{{ URL::to('assets/css/theme-styles.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ URL::to('assets/css/blocks.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ URL::to('assets/css/fonts.css') }}">

	<!-- Styles for plugins -->
	<link rel="stylesheet" type="text/css" href="{{ URL::to('assets/css/jquery.mCustomScrollbar.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ URL::to('assets/css/daterangepicker.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ URL::to('assets/css/bootstrap-select.css') }}">
</head>
@yield('content')

<!-- jQuery first, then Other JS. -->
<script src="{{ URL::to('assets/js/jquery-3.2.0.min.js') }}"></script>
<!-- Js effects for material design. + Tooltips -->
<script src="{{ URL::to('assets/js/material.min.js') }}"></script>
<!-- Helper scripts (Tabs, Equal height, Scrollbar, etc) -->
<script src="{{ URL::to('assets/js/theme-plugins.js') }}"></script>
<!-- Init functions -->
<script src="{{ URL::to('assets/js/main.js') }}"></script>

<!-- Load more news AJAX script -->
<script src="{{ URL::to('assets/js/ajax-pagination.js') }}"></script>

<!-- Select / Sorting script -->
<script src="{{ URL::to('assets/js/selectize.min.js') }}"></script>

<!-- Swiper / Sliders -->
<script src="{{ URL::to('assets/js/swiper.jquery.min.js') }}"></script>

<!-- Datepicker input field script-->
<script src="{{ URL::to('assets/js/moment.min.js') }}"></script>
<script src="{{ URL::to('assets/js/daterangepicker.min.js') }}"></script>

<script src="{{ URL::to('assets/js/mediaelement-and-player.min.js') }}"></script>
<script src="{{ URL::to('assets/js/mediaelement-playlist-plugin.min.js') }}"></script>

@yield('extrajs')

</body>
</html>