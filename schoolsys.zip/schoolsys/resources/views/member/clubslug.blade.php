
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>{{ $clubs->title }} :: Club</title>
      <link rel="stylesheet" href="../../bootstrap.css" media="screen">
    <link rel="stylesheet" href="../../custom.min.css">
    <link rel="stylesheet" href="../../comment.css">
    

  </head>

<body style="margin-top: -50px;">
	<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">School</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="{{ route('memberfeed') }}">Home <span class="sr-only">(current)</span></a></li>

      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="{{ route('logout') }}">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

    <div class="container" >
    <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-4">
            <div class="list-group table-of-contents">
              <a class="list-group-item" href="{{ route('memberfeed') }}">News Feed</a>
              <a class="list-group-item" href="{{ route('memberclub') }}">Clubs</a>
              <!--<a class="list-group-item" href="{{ route('memberprofile') }}">My Profile </a>-->
              <a class="list-group-item" href="{{ route('memberaccount') }}">Account </a>
            </div>
          </div>
          <div class="col-lg-9 col-md-9 col-sm-8">
          @include('includes.error')
      @include('includes.warning')
      @include('includes.success')
          		<div class="row">
          		<h3>About {{ $clubs->title }}</h3>
          		<p>{{ $clubs->description }}
          		</div>
          		<hr>
          		@if ($clubmember == 1 && $clubs->type=="local")
          		<!--<form method="post" action="" id="Status">
								<div class="form-group with-icon label-floating is-empty">
									<label class="control-label">Share Post to all Members..</label>
									<textarea class="form-control" placeholder="{{ Auth::user()->profile->first()->lname }} {{ Auth::user()->profile->first()->fname }} Send a Post to Members of {{ $clubs->title }}" name="post"></textarea>
								</div>
								<button class="btn btn-primary btn-md-2" type="submit">Share</button>
								<input type="hidden" name="_token" value="{{ Session::token() }}">
				</form>
          		<hr>-->
          		<div class="row">
          			@foreach($clubpost as $post)
				<div class="detailBox">
				    <div class="titleBox">
				      <label>
				      <div class="commenterImage">
				                  <img src="{{ URL::to('avatar') }}/{{ $post->user->profile->first()->avatar }}" />
				                </div>
				                Post By {{ $post->user->profile->first()->lname }} {{ $post->user->profile->first()->fname }}  ( <small>{{ $post->created_at->diffForHumans() }}</small> )</label>				    </div>
				    <div class="commentBox">
				        <p class="taskDescription">{{ $post->post }}</p>
				    </div>
            <div class="commentBox">
                <ul class="commentList">
                @foreach ($post->comment  as $comment)
                    <li>
                        <div class="commenterImage">
                          <img src="{{ URL::to('avatar') }}/{{ $comment->user->profile->first()->avatar }}" />
                        </div>
                        <div class="commentText">
                            <p class="">{{ $comment->comment }}</p> <span class="date sub-text">Comment By {{ $comment->user->profile->first()->lname }} {{ $comment->user->profile->first()->fname }}  {{ $comment->created_at->diffForHumans() }}</span>
                        </div>
                    </li>
                @endforeach
                </ul>
                <form class="form-inline" method="post" action="{{ route('memberpostclubcomment',$post->id) }}">
                    <div class="form-group">
                        <input class="form-control" type="text" placeholder="{{ Auth::user()->profile->first()->lname }} {{ Auth::user()->profile->first()->fname }} Comment" name="comment" onsubmit="submit();"/>
                        <input type="hidden" name="_token" value="{{ Session::token() }}">
                    </div>
                </form>
            </div>
				</div>
				@endforeach
          		</div>
          		<div class="row">
          		<h2>Learning Materials</h2>
          			<table class="table table-striped">
          				<thead>
          					<tr>
          						<th>Title</th>
          						<th>Link</th>
          					</tr>
          				</thead>
          				<tbody>
          				@foreach($ebooks as $books)
          					<tr>
          						<td>{{ $books->file }}</td>
          						<td><a href="{{ URL::to('Books') }}/{{ $books->file }}" target="_blank">View</a></td>
          					</tr>
          				@endforeach
          				</tbody>
          			</table>
				</div>
        @elseif ($clubmember == 1 && $clubs->type == "external")
        <div class="row">
          {!!$member->iframe!!}
        </div>
				<hr>
				<div class="row">
				<form class="form-horizontal" method="post" action="{{ route('membersaveebook',$clubs->id) }}" enctype="multipart/form-data">
				<h3>Share Ebook</h3>
					<div class="form-group">
					    <label for="exampleInputEmail1">File</label>
					    <input type="file" class="form-control" name="ebook" required>
					    <button class="btn btn-primary" type="submit">Submit</button>
					    <input type="hidden" name="_token" value="{{ Session::token() }}">
					 </div>
				</form>
				</div>
        
				<hr>
				@elseif ($clubmember == 0)
				Whoops! You are not a Member of {{ $clubs->title }}, Please Join Club to Gain Access to Content<br>
				<form method="post" action="{{ route('joinclub',$clubs->id) }}">
          @if ($clubs->type == 'local')
					<button type="submit" class="btn btn-success btn-md-2" >Join {{ $clubs->title }} </button>
          @elseif ($clubs->type == 'external')
          <div class="form-group">
          <a href="{{$clubs->url}}" class="btn btn-success btn-md-2" target="_blank">Join {{ $clubs->title }} </a>
          </div>
          <div class="form-group">
            <textarea class="form-control" name="iframe" placeholder="Enter iframe code" required></textarea>
          </div>
          <button type="submit" class="btn btn-success btn-md-2" >Submit</button>
          @endif
					<input type="hidden" name="_token" value="{{ Session::token() }}">
				</form>
				
				@endif
				

          </div>

          
    </div>

    </div>
       <!-- Bootstrap core JavaScript
    ================================================== -->
        
    

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../../custom.js"></script>
<!-- Laravel Javascript Validation -->
<script type="text/javascript" src="{{ asset('vendor/jsvalidation/js/jsvalidation.js')}}"></script>
{!! JsValidator::formRequest('App\Http\Requests\PostRequest', '#SignIn') !!}
  </body>
</html>
