<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [
		'uses' => 'frontend\PageController@index',
		'as' => 'index'
]);

Route::get('/register', [
		'uses' => 'frontend\PageController@register',
		'as' => 'register'
]);

Route::post('/register-member', [
		'uses' => 'auth\AuthController@registermember',
		'as' => 'registermember'
]);

Route::post('/sign-in', [
		'uses' => 'auth\AuthController@signin',
		'as' => 'signin'
]);

Route::get('/logout', [
		'uses' => 'auth\AuthController@logout',
		'as' => 'logout'
]);


// OAuth Routes
Route::get('auth/{provider}', 'auth\AuthController@redirectToProvider');
Route::get('auth/{provider}/callback', 'auth\AuthController@handleProviderCallback');



Route::group([ 'middleware' => 'web', 'prefix' => 'member', 'before' => 'member' ], function(){
	
	Route::get('/feed', [
		'uses' => 'member\PageController@feed',
		'as' => 'memberfeed'
	]);	

	Route::post('/poststatus', [
		'uses' => 'member\PostController@poststatus',
		'as' => 'memberpoststatus'
	]);

	Route::post('/postcomment/{id}', [
		'uses' => 'member\PostController@postcomment',
		'as' => 'memberpostcomment'
	]);

	Route::post('/postclubcomment/{id}', [
		'uses' => 'member\PostController@postclubcomment',
		'as' => 'memberpostclubcomment'
	]);

	Route::get('/clubs', [
		'uses' => 'member\PageController@club',
		'as' => 'memberclub'
	]);

	Route::get('/club/{slug}', [
		'uses' => 'member\PageController@clubslug',
		'as' => 'memberclubslug'
	]);

	Route::post('/joinclub/{id}', [
		'uses' => 'member\PostController@joinclub',
		'as' => 'joinclub'
	]);

	Route::post('/saveebook/{id}', [
		'uses' => 'member\PostController@saveebook',
		'as' => 'membersaveebook'
	]);

	Route::get('/account', [
		'uses' => 'member\PageController@account',
		'as' => 'memberaccount'
	]);

	Route::get('/profile', [
		'uses' => 'member\PageController@memberprofile',
		'as' => 'memberprofile'
	]);
	
		   
});



Route::group([ 'middleware' => 'web', 'prefix' => 'admin', 'before' => 'admin' ], function(){
	
	
	Route::get('/members', [
		'uses' => 'member\PageController@adminmembers',
		'as' => 'adminmembers'
	]);	

	Route::get('/profile/{id}', [
		'uses' => 'member\PageController@profile',
		'as' => 'profile'
	]);	

	Route::get('/clubs', [
		'uses' => 'member\PageController@adminclubs',
		'as' => 'adminclubs'
	]);	

	Route::post('/saveclub', [
		'uses' => 'member\PostController@saveclub',
		'as' => 'saveclub'
	]);

	Route::get('/clubs/{id}', [
		'uses' => 'member\PageController@adminclubspost',
		'as' => 'adminclubspost'
	]);	

		Route::post('/saveclubpost/{id}', [
		'uses' => 'member\PostController@saveclubpost',
		'as' => 'adminsaveclubpost'
	]);
		   
});