
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>School :: Register</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">
    
  </head>

<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">School</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="<?php echo e(route('index')); ?>">Home <span class="sr-only">(current)</span></a></li>

      </ul>
    </div>
  </div>
</nav>

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron" style="background-image: url('imageedit_1_3973662003.png');">
      <div class="container">
        <h1 class="display-3">School Grip</h1>
        <p>A simple social platform for sharing content and messgaes within student</p>
        <p><a class="btn btn-primary btn-lg" href="<?php echo e(route('index')); ?>" role="button">Already a Student ? &raquo;</a></p>
      </div>
    </div>
    <div class="row" style="background-image: url('imageedit_1_3973662003.png');">
    <?php echo $__env->make('includes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('includes.warning', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('includes.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    	<div class="container">
    	<div class="col-md-3"></div>
    	<div class="col-md-6 offset-md-2">
	    		<form class="content" method="post" action="<?php echo e(route('registermember')); ?>" id="SignUp">
							<div class="row">
								<div class="col-lg-6 col-md-6 <?php echo e($errors->has('fname') ? 'has-error' : ''); ?>">
									<div class="form-group label-floating is-empty">
										<label class="control-label">First Name</label>
										<input class="form-control" placeholder="" type="text" name="fname" id="fname">
									</div>
								</div>
								<div class="col-lg-6 col-md-6 <?php echo e($errors->has('lname') ? 'has-error' : ''); ?>">
									<div class="form-group label-floating is-empty">
										<label class="control-label">Last Name</label>
										<input class="form-control" placeholder="" type="text" name="lname">
									</div>
								</div>
								</div>
								<div class="row">
								<div class="col-xl-6 col-lg-6 col-md-6 <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
									<div class="form-group label-floating is-empty">
										<label class="control-label">Your Email</label>
										<input class="form-control" placeholder="" type="email" name="email">
									</div>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
								<div class="form-group label-floating is-select ">
										<label class="control-label">Your Gender</label>
										<select class="selectpicker form-control" size="auto" name="gender">
											<option disabled selected></option>
											<option value="M">Male</option>
											<option value="F">Female</option>
										</select>
								</div>
								</div>
								</div>
								<div class="row">
								<div class="col-lg-6 col-md-6 <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
									<div class="form-group label-floating is-empty ">
										<label class="control-label">Password</label>
										<input class="form-control" placeholder="" type="password" name="password">
									</div>
								</div>
								<div class="col-lg-6 col-md-6 <?php echo e($errors->has('confirm_password') ? 'has-error' : ''); ?>">
									<div class="form-group label-floating is-empty ">
										<label class="control-label">Confirm Password</label>
										<input class="form-control" placeholder="" type="password" name="confirm_password">
									</div>
								</div>
								</div>
								<div class="row">
								<div class="col-lg-12 col-md-12 <?php echo e($errors->has('confirm_password') ? 'has-error' : ''); ?>">
									<div class="remember">
										<div class="checkbox">
											<label>
												<input name="agree" type="checkbox" required>
												I accept the <a href="#">Terms and Conditions</a> of the website
											</label>
										</div>
									</div>
									<button class="btn btn-purple btn-lg full-width" type="submit">Complete Registration!</button>
									<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
								</div>
								</div>
							</div>
						</form>
		</div>
    	</div>
    </div>

    <hr>
       <!-- Bootstrap core JavaScript
    ================================================== -->
    
    
    


<!-- Javascript Requirements -->
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="popper.min.js"></script>
<script type="text/javascript">
    //https://orgsync.com/login/arizona-state-university?redirect_to=%2Fhome%2F234
    function validate(el){
    	var email = el.value;
    	var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    	if(re.test(email)){
	    	if(email.indexOf("@asu.edu", email.length - "@asu.edu".length) !== -1){
	    		console.log($(el).parent('form-group:first'));
	    		

	    	}else{
	    		console.log('Only @asu.edu emails are allowed');
	    		$(el).attr('aria-invalid',true);
	    		$(el).parent('form-group').removeClass('has-success').addClass('has-error');
	    		$(el).parent('form-group').find('#email-error').remove();
	    		$(el).parent('form-group').append('<span id="email-error" class="help-block error-help-block">Gmail email is not allowed.</span>');
	    	}
    	}
    }
    </script>
<!-- Laravel Javascript Validation -->
<script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>

<?php echo JsValidator::formRequest('App\Http\Requests\SignUp'); ?>

  </body>
</html>
