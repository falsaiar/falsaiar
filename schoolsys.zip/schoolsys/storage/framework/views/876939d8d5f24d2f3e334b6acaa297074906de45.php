
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>School</title>
      <link rel="stylesheet" href="../bootstrap.css" media="screen">
    <link rel="stylesheet" href="../custom.min.css">
    <link rel="stylesheet" href="../comment.css">
    

  </head>

<body style="margin-top: -50px;">
	<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">School</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="<?php echo e(route('memberfeed')); ?>">Home <span class="sr-only">(current)</span></a></li>

      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

    <div class="container" >
    <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-4">
            <div class="list-group table-of-contents">
              <a class="list-group-item" href="<?php echo e(route('memberfeed')); ?>">News Feed</a>
              <a class="list-group-item" href="<?php echo e(route('memberclub')); ?>">Clubs</a>
              <!--<a class="list-group-item" href="<?php echo e(route('memberprofile')); ?>">My Profile </a>-->
              <a class="list-group-item" href="<?php echo e(route('memberaccount')); ?>">Account </a>
            </div>
          </div>
          <div class="col-lg-9 col-md-9 col-sm-8">
          <?php echo $__env->make('includes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('includes.warning', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('includes.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="row">
              <h3>Update Credentials</h3>
                <form method="post">
                <img src="" class="thumb img-responsive">
                <label>Update Profile Image</label>
                <input type="file" name="image" onchange="submit();"">
                </form>
              </div>
              <hr>
                <form method="post">
                  <div class="row" style="margin-bottom: 15px;">
                    <div class="form-group">
                        <div class="col-md-4">
                            <input type="text" name="fname" class="form-control" placeholder="Please Enter First Name" value="<?php echo e(Auth::user()->profile->first()->fname); ?>">
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="lname" class="form-control" placeholder="Please Enter Last Name" value="<?php echo e(Auth::user()->profile->first()->lname); ?>">
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="phone" class="form-control" placeholder="Please Enter Phone Number" value="<?php echo e(Auth::user()->profile->first()->phone); ?>">
                        </div>
                    </div>
                  </div>

                  <div class="row" style="margin-bottom: 15px;">
                    <div class="form-group">
                        <div class="col-md-4">
                            <input type="text" name="country" class="form-control" placeholder="Please Enter Country" value="<?php echo e(Auth::user()->profile->first()->country); ?>">
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="state" class="form-control" placeholder="Please Enter State" value="<?php echo e(Auth::user()->profile->first()->state); ?>">
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="city" class="form-control" placeholder="Please Enter City" value="<?php echo e(Auth::user()->profile->first()->city); ?>">
                        </div>
                    </div>
                  </div>

                  <div class="row" style="margin-bottom: 15px;">
                    <div class="form-group">
                        <div class="col-md-4">
                            <input type="text" name="fb" class="form-control" placeholder="Facebook Account" value="<?php echo e(Auth::user()->profile->first()->fb); ?>">
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="google" class="form-control" placeholder="Twitter Account" value="<?php echo e(Auth::user()->profile->first()->tw); ?>">
                        </div>
                        <div class="col-md-4">
                            <input type="text" name="google" class="form-control" placeholder="Google Plus Account" value="<?php echo e(Auth::user()->profile->first()->go); ?>">
                        </div>
                    </div>
                  </div>
                  <div class="row" style="margin-top: 15px;">
                      <button class="btn btn-primary pull-right" type="submit">Update</button>
                  </div>
                </form>

              <h3>Change Password</h3>
                <div class="row">
                        <div class="col-md-4">
                            <input type="password" name="old_password" class="form-control" placeholder="Enter Current Password">
                        </div>
                        <div class="col-md-4">
                            <input type="password" name="new_password" class="form-control" placeholder="New Password">
                        </div>
                        <div class="col-md-4">
                            <input type="password" name="confirm_new_password" class="form-control" placeholder="Confirm New Password">
                        </div>
                </div>
                <div class="row">
                    <button class="btn btn-primary" type="submit">Change Password</button>
                </div>
              </div>
          </div>
    </div>

    </div>
       <!-- Bootstrap core JavaScript
    ================================================== -->
        <script src="../bootstrap.min.js"></script>
    <script src="../custom.js"></script


<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>

<!-- Laravel Javascript Validation -->
<script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<?php echo JsValidator::formRequest('App\Http\Requests\SignIn', '#SignIn'); ?>

  </body>
</html>
