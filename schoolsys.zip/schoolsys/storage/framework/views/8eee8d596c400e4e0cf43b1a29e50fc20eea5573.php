
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title> Club</title>
      <link rel="stylesheet" href="../bootstrap.css" media="screen">
    <link rel="stylesheet" href="../custom.min.css">
    <link rel="stylesheet" href="../comment.css">
    

  </head>

<body style="margin-top: -50px;">
	<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">School</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="<?php echo e(route('memberfeed')); ?>">Home <span class="sr-only">(current)</span></a></li>

      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

    <div class="container" >
    <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-4">
            <div class="list-group table-of-contents">
              <a class="list-group-item" href="<?php echo e(route('memberfeed')); ?>">News Feed</a>
              <a class="list-group-item" href="<?php echo e(route('memberclub')); ?>">Clubs</a>
              <!--<a class="list-group-item" href="<?php echo e(route('memberprofile')); ?>">My Profile </a>-->
              <a class="list-group-item" href="<?php echo e(route('memberaccount')); ?>">Account </a>
            </div>
          </div>
          <div class="col-lg-9 col-md-9 col-sm-8">
          <?php echo $__env->make('includes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('includes.warning', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('includes.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          		<div class="row">
          		<?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  <div class="col-xs-6 col-md-3">
				    <a href="<?php echo e(route('memberclubslug',$club->slug)); ?>" class="thumbnail">
				      <img src="../School_Club.jpg" alt="...">
				    </a>
				    <h4><?php echo e($club->title); ?></h4>
				  </div>
				 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
          </div>

          <?php echo e($clubs->links()); ?>

    </div>

    </div>
       <!-- Bootstrap core JavaScript
    ================================================== -->
        
    


<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../custom.js"></script>
<!-- Laravel Javascript Validation -->
<script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<?php echo JsValidator::formRequest('App\Http\Requests\SignIn', '#SignIn'); ?>

  </body>
</html>
