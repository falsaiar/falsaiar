
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>School</title>
      <link rel="stylesheet" href="../bootstrap.css" media="screen">
    <link rel="stylesheet" href="../custom.min.css">
    <link rel="stylesheet" href="../comment.css">
    

  </head>

<body style="margin-top: -50px;">
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">School</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home <span class="sr-only">(current)</span></a></li>

      </ul>
    </div>
  </div>
</nav>

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron" style="background-image: url('imageedit_1_3973662003.png');">
      <div class="container">
        <h1 class="display-3">School Grip</h1>
        <p>A simple social platform for sharing content and messgaes within student</p>
        <p><a class="btn btn-primary btn-lg" href="<?php echo e(route('register')); ?>" role="button">New Student ? &raquo;</a></p>
      </div>
    </div>
    <div class="row" style="background-image: url('imageedit_1_3973662003.png');">
    <?php echo $__env->make('includes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('includes.warning', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('includes.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    	<div class="container">
      <div class="col-md-3"></div>
        <div class="col-md-6 offset-md-2">
	    		<form class="form-horizontal" method="post" action="<?php echo e(route('signin')); ?>" id="SignIn">
				  <fieldset>
				    <legend>Already have an Account</legend>
				    <div class="form-group">
				      <label for="inputEmail" class="col-lg-2 control-label">Email</label>
				      <div class="col-lg-10">
				        <input type="text" class="form-control" id="email" name="email" placeholder="Email">
				      </div>
				    </div>
				    <div class="form-group">
				      <label for="inputPassword" class="col-lg-2 control-label">Password</label>
				      <div class="col-lg-10">
				        <input type="password" class="form-control" id="password" name="password" placeholder="Password">
				      </div>
				    </div>
				    <div class="form-group">
				      <div class="col-lg-10 col-lg-offset-2">
				        <button type="submit" class="btn btn-success">Login</button>
				      </div>
				    </div>
				  </fieldset>
				  <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
				</form>
      </div>
    	</div>
    </div>

    <hr>
       <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
      <script src="../bootstrap.min.js"></script>
    <script src="../custom.js"></script


<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>


<!-- Laravel Javascript Validation -->
<script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<?php echo JsValidator::formRequest('App\Http\Requests\SignIn', '#SignIn'); ?>

  </body>
</html>
