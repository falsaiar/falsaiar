
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title><?php echo e($clubs->title); ?> :: Club</title>
      <link rel="stylesheet" href="../../bootstrap.css" media="screen">
    <link rel="stylesheet" href="../../custom.min.css">
    <link rel="stylesheet" href="../../comment.css">
    

  </head>

<body style="margin-top: -50px;">
	<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">School</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="<?php echo e(route('memberfeed')); ?>">Home <span class="sr-only">(current)</span></a></li>

      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

    <div class="container" >
    <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-4">
            <div class="list-group table-of-contents">
              <a class="list-group-item" href="<?php echo e(route('memberfeed')); ?>">News Feed</a>
              <a class="list-group-item" href="<?php echo e(route('memberclub')); ?>">Clubs</a>
              <!--<a class="list-group-item" href="<?php echo e(route('memberprofile')); ?>">My Profile </a>-->
              <a class="list-group-item" href="<?php echo e(route('memberaccount')); ?>">Account </a>
            </div>
          </div>
          <div class="col-lg-9 col-md-9 col-sm-8">
          <?php echo $__env->make('includes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('includes.warning', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('includes.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          		<div class="row">
          		<h3>About <?php echo e($clubs->title); ?></h3>
          		<p><?php echo e($clubs->description); ?>

          		</div>
          		<hr>
          		<?php if($clubmember == 1 && $clubs->type=="local"): ?>
          		<!--<form method="post" action="" id="Status">
								<div class="form-group with-icon label-floating is-empty">
									<label class="control-label">Share Post to all Members..</label>
									<textarea class="form-control" placeholder="<?php echo e(Auth::user()->profile->first()->lname); ?> <?php echo e(Auth::user()->profile->first()->fname); ?> Send a Post to Members of <?php echo e($clubs->title); ?>" name="post"></textarea>
								</div>
								<button class="btn btn-primary btn-md-2" type="submit">Share</button>
								<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
				</form>
          		<hr>-->
          		<div class="row">
          			<?php $__currentLoopData = $clubpost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="detailBox">
				    <div class="titleBox">
				      <label>
				      <div class="commenterImage">
				                  <img src="<?php echo e(URL::to('avatar')); ?>/<?php echo e($post->user->profile->first()->avatar); ?>" />
				                </div>
				                Post By <?php echo e($post->user->profile->first()->lname); ?> <?php echo e($post->user->profile->first()->fname); ?>  ( <small><?php echo e($post->created_at->diffForHumans()); ?></small> )</label>				    </div>
				    <div class="commentBox">
				        <p class="taskDescription"><?php echo e($post->post); ?></p>
				    </div>
            <div class="commentBox">
                <ul class="commentList">
                <?php $__currentLoopData = $post->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <div class="commenterImage">
                          <img src="<?php echo e(URL::to('avatar')); ?>/<?php echo e($comment->user->profile->first()->avatar); ?>" />
                        </div>
                        <div class="commentText">
                            <p class=""><?php echo e($comment->comment); ?></p> <span class="date sub-text">Comment By <?php echo e($comment->user->profile->first()->lname); ?> <?php echo e($comment->user->profile->first()->fname); ?>  <?php echo e($comment->created_at->diffForHumans()); ?></span>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <form class="form-inline" method="post" action="<?php echo e(route('memberpostclubcomment',$post->id)); ?>">
                    <div class="form-group">
                        <input class="form-control" type="text" placeholder="<?php echo e(Auth::user()->profile->first()->lname); ?> <?php echo e(Auth::user()->profile->first()->fname); ?> Comment" name="comment" onsubmit="submit();"/>
                        <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                    </div>
                </form>
            </div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          		</div>
          		<div class="row">
          		<h2>Learning Materials</h2>
          			<table class="table table-striped">
          				<thead>
          					<tr>
          						<th>Title</th>
          						<th>Link</th>
          					</tr>
          				</thead>
          				<tbody>
          				<?php $__currentLoopData = $ebooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $books): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          					<tr>
          						<td><?php echo e($books->file); ?></td>
          						<td><a href="<?php echo e(URL::to('Books')); ?>/<?php echo e($books->file); ?>" target="_blank">View</a></td>
          					</tr>
          				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          				</tbody>
          			</table>
				</div>
        <?php elseif($clubmember == 1 && $clubs->type == "external"): ?>
        <div class="row">
          <?php echo $member->iframe; ?>

        </div>
				<hr>
				<div class="row">
				<form class="form-horizontal" method="post" action="<?php echo e(route('membersaveebook',$clubs->id)); ?>" enctype="multipart/form-data">
				<h3>Share Ebook</h3>
					<div class="form-group">
					    <label for="exampleInputEmail1">File</label>
					    <input type="file" class="form-control" name="ebook" required>
					    <button class="btn btn-primary" type="submit">Submit</button>
					    <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
					 </div>
				</form>
				</div>
        
				<hr>
				<?php elseif($clubmember == 0): ?>
				Whoops! You are not a Member of <?php echo e($clubs->title); ?>, Please Join Club to Gain Access to Content<br>
				<form method="post" action="<?php echo e(route('joinclub',$clubs->id)); ?>">
          <?php if($clubs->type == 'local'): ?>
					<button type="submit" class="btn btn-success btn-md-2" >Join <?php echo e($clubs->title); ?> </button>
          <?php elseif($clubs->type == 'external'): ?>
          <div class="form-group">
          <a href="<?php echo e($clubs->url); ?>" class="btn btn-success btn-md-2" target="_blank">Join <?php echo e($clubs->title); ?> </a>
          </div>
          <div class="form-group">
            <textarea class="form-control" name="iframe" placeholder="Enter iframe code" required></textarea>
          </div>
          <button type="submit" class="btn btn-success btn-md-2" >Submit</button>
          <?php endif; ?>
					<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
				</form>
				
				<?php endif; ?>
				

          </div>

          
    </div>

    </div>
       <!-- Bootstrap core JavaScript
    ================================================== -->
        
    

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="../../custom.js"></script>
<!-- Laravel Javascript Validation -->
<script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<?php echo JsValidator::formRequest('App\Http\Requests\PostRequest', '#SignIn'); ?>

  </body>
</html>
