<?php if(Session::has('flash_message')): ?>
<div class="alert alert-warning alert-dismissible fade in">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
  <?php echo e(Session::get('flash_message')); ?>

</div>
<?php endif; ?> 

